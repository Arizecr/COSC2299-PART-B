# COSC-2299-Part-A
Tutor's name: A Homy Ash

Tute/Lab class: Monday 8:30am

Wei Zhi s3581263  
Yesmi s3543729  
Gabrielle s3605767  
Martin s3607187

Wei Zhi s3581263  - responsible for user documentation[user stories, acceptance testing] and employee availability
Yesmi s3543729  - responsible for Testing and Add workhours, Add employee worktimes and Remove employee worktimes
Gabrielle s3605767  - responsible for Coding and wireframes, code refractoring, Scrum Master
Martin s3607187 - responsible for Coding and wireframes, code refractoring

Team Contribution

Wei Zhi s3581263      25%
Yesmi s3543729        25%
Gabrielle s3605767    25%
Martin s3607187       25%

Important links:
Trello: https://trello.com/b/6jQXB7yR/software-engineeringmycw
Github: https://github.com/Arizecr/COSC-2299-Part-A
Slack: sefparta.slack.com

