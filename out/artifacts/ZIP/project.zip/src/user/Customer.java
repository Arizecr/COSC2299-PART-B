package user;

import userBase.User;

/**
 * Created by Martin on 5/03/2017.
 */
public class Customer extends User{

    public Customer(String username, String password, String fullName, String address, String phoneNo){
        super(username, password, fullName, address, phoneNo);
    }


}
